/*
            __          __
       __  / /\________/ /\    __
    __/ /\/ /  \______/ /  \__/ /\
   /_/\/ / / /\ \____/ / /\/_/\/ /
   \_\  / /  \/ / / / / / /\_\  /
   / /  \/ /\  / / / /  \/ / /  \
  / / /\ \/\_\/_/ / / /\  / / /\ \
 / / /\_\/ / /___/ / /\_\/ / /\_\/
/_/ /_/ /\/_____/_/ / / /_/ /
\ \ \_\/        \_\/ /_/\ \ \
 \_\/                \_\/\_\/

	MAPIMP Plugin version 0.6
	coded by takerZ/tPORt
	mob by BoRoV/TSRh
	2009

You can do with the source everything you want.
You can steal it, you can burn it, you can...
Everything! Really. BUT still remember that:

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE blah blah blah
*/
#include <windows.h>
#include <psapi.h>
#include <commctrl.h>
#include <stdio.h>
#include <string.h>

#define PCRE_STATIC

/* use PCRE library */
#include "pcreposix.h"
/* and OllyDbg Plugin SDK v1.1 to compile */
#include "plugin.h"
#include "mapimp.h"

/*
Make sure that you compile it with default char
unsigned and multi-byte character set
*/

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "ollydbgvc7.lib")
#pragma comment(lib, "pcre.lib")
#pragma comment(lib, "pcreposix.lib")

HWND g_hwndOlly;
HINSTANCE g_hInstance, g_hInstDLL;
HFONT g_hFont;
CONFIG* g_Config;
PCHAR g_LastSession;
BOOL g_SessionStarted;
DWORD isAlready = 0;

int mask_compile(MASK* msk, PCHAR str)
{
	int result, counter;
	if (str[0] == '/')
	{
		if ((str[1] == 's') || (str[1] == 'S'))
		{
			result = regcomp(&msk->regex, str + 2, 0);
			if (!result)
			{
				msk->type = FILTER_SKIP;
				return FILTER_NOERROR;
			}
			else
			{
				return result;
			}
		}
		else if ((str[1] == 'c') || (str[1] == 'C'))
		{
			result = regcomp(&msk->regex, str + 2, 0);
			if (!result)
			{
				msk->type = FILTER_CUT;
				return FILTER_NOERROR;
			}
			else
			{
				return result;
			}
		}
		else if ((str[1] == 'r') || (str[1] == 'R'))
		{
			msk->repl = malloc(TEXTLEN * sizeof(char));
			for (counter = 2; TRUE; counter++)
			{
				if (str[counter] == '\0')
				{
					free(msk->repl);
					return FILTER_INVALID_REPLACEMENT;
				}
				else if (str[counter] == '/')
				{
					if (str[counter + 1] == '/')
					{
						msk->repl[counter - 2] = str[counter];
						counter++;
					}
					else
					{
						break;
					}
				}
				else
				{
					msk->repl[counter - 2] = str[counter];
				}
			}
			msk->repl[counter - 2] = '\0';
			result = regcomp(&msk->regex, str + counter + 1, 0);
			if (!result)
			{
				msk->type = FILTER_REPLACE;
				return FILTER_NOERROR;
			}
			else
			{
				return result;
			}
		}
		else
		{
			return FILTER_INVALID_KEY;
		}
	}
	else
	{
		return FILTER_INVALID_MASK;
	}
}

void mask_error(int err, regex_t* regex, PCHAR buffer)
{
	switch (err)
	{
		case FILTER_NOERROR:
			break;
		case FILTER_INVALID_MASK:
			strcpy(buffer, "mask magic / is not present");
			break;
		case FILTER_INVALID_KEY:
			strcpy(buffer, "unknown key");
			break;
		case FILTER_INVALID_REPLACEMENT:
			strcpy(buffer, "trailing / which closes replacement is not found");
			break;
		default:
			/* Stack corruption warning! buffer length may not be enough, but I hope it is */
			regerror(err, regex, buffer, ERRORBUFLEN);
	}
}

int mask_filter(NAME* name)
{
	ULONG counter, ending, result = FILTER_NOTHING;
	char buffer[TEXTLEN], part[TEXTLEN];
	regmatch_t* matchs = malloc(name->size * sizeof(regmatch_t));
	MASK* msk = (MASK*)g_Config->customfilter->first;
	while (msk)
	{
		if (msk->type == FILTER_SKIP)
		{
			if (!regexec(&msk->regex, name->buffer, name->size, matchs, 0))
			{
				name->buffer[0] = '\0';
				result |= FILTER_SKIP;
				break;
			}
		}
		else if (msk->type == FILTER_CUT)
		{
			while (!regexec(&msk->regex, name->buffer, name->size, matchs, 0))
			{
				buffer[0] = '\0';
				strncpy(part, name->buffer, matchs[0].rm_so);
				part[matchs[0].rm_so] = '\0';
				strcat(buffer, part);
				for (counter = 1; counter < name->size; counter++)
				{
					if (matchs[counter].rm_so != -1)
					{
						ending = matchs[counter].rm_so - matchs[counter - 1].rm_eo;
						strncpy(part, name->buffer + matchs[counter - 1].rm_eo, ending);
						part[ending] = '\0';
						strcat(buffer, part);
					}
					else
					{
						break;
					}
				}
				ending = name->size - matchs[counter - 1].rm_eo;
				strncpy(part, name->buffer + matchs[counter - 1].rm_eo, ending);
				strcat(buffer, part);
				strcpy(name->buffer, buffer);
				result |= FILTER_CUT;
			}
		}
		else /* if (msk->type == FILTER_REPLACE) */
		{
			while (!regexec(&msk->regex, name->buffer, name->size, matchs, 0))
			{
				buffer[0] = '\0';
				strncpy(part, name->buffer, matchs[0].rm_so);
				part[matchs[0].rm_so] = '\0';
				strcat(buffer, part);
				strcat(buffer, msk->repl);
				for (counter = 1; counter < name->size; counter++)
				{
					if (matchs[counter].rm_so != -1)
					{
						ending = matchs[counter].rm_so - matchs[counter - 1].rm_eo;
						strncpy(part, name->buffer + matchs[counter - 1].rm_eo, ending);
						part[ending] = '\0';
						strcat(buffer, part);
						strcat(buffer, msk->repl);
					}
					else
					{
						break;
					}
				}
				ending = name->size - matchs[counter - 1].rm_eo;
				strncpy(part, name->buffer + matchs[counter - 1].rm_eo, ending);
				strcat(buffer, part);
				free(name->buffer);
				name->buffer = malloc((strlen(buffer) + 1) * sizeof(char));
				strcpy(name->buffer, buffer);
				result |= FILTER_REPLACE;
			}
		}
		msk = msk->next;
	}
	free(matchs);
	return result;
}

void mask_free(MASK* msk)
{
	regfree(&msk->regex);
	free(msk->buffer);
	if (msk->type == FILTER_REPLACE)
	{
		free(msk->repl);
	}
}

LIST* list_create()
{
	LIST* list = malloc(sizeof(LIST));
	list->count = 0;
	list->first = NULL;
	list->last = NULL;
	return list;
}

LIST* list_addmask(LIST* lst, PCHAR str)
{
	MASK* msk = malloc(sizeof(MASK));
	MASK* tmp;
	if (str)
	{
		if (mask_compile(msk, str))
		{
			free(msk);
		}
		else
		{
			msk->buffer = malloc((strlen(str) + 1) * sizeof(char));
			strcpy(msk->buffer, str);
			if (!lst->first)
			{
				lst->first = (PVOID)msk;
				lst->last = (PVOID)msk;
			}
			else
			{
				tmp = (MASK*)lst->last;
				tmp->next = msk;
				lst->last = (PVOID)msk;
			}
			msk->next = NULL;
			lst->count++;
		}
	}
	return lst;
}

LIST* list_addname(LIST* lst, PCHAR name, ULONG length, BYTE segment, ULONG offset)
{
	NAME* nm = malloc(sizeof(NAME));
	NAME* tmp;
	if (name)
	{
		nm->size = length + 1;
		nm->buffer = malloc(nm->size * sizeof(char));
		strcpy(nm->buffer, name);
		nm->segment = segment;
		nm->offset = offset;
		if (!lst->first)
		{
			lst->first = (PVOID)nm;
			lst->last = (PVOID)nm;
		}
		else
		{
			tmp = (NAME*)lst->last;
			tmp->next = nm;
			lst->last = (PVOID)nm;
		}
		nm->next = NULL;
		lst->count++;
	}
	return lst;
}

void list_freemasks(LIST* lst)
{
	MASK* msk = (MASK*)lst->first;
	MASK* lastmsk;
	while (msk)
	{
		mask_free(msk);
		lastmsk = msk;
		msk = msk->next;
		free(lastmsk);
	}
	free(lst);
}

void list_freenames(LIST* lst)
{
	NAME* nm = (NAME*)lst->first;
	NAME* lastnm;
	while (nm)
	{
		free(nm->buffer);
		lastnm = nm;
		nm = nm->next;
		free(lastnm);
	}
	free(lst);
}

BOOL configfile_create(PCHAR path, CONFIG* conf)
{
	FILE* file = fopen(path, "w");
	char buffer[TEXTLEN], value[6];
	MASK* msk;
	if (file)
	{
		fputs("// WARNING! If you want to edit this config file manually,\n", file);
		fputs("// please, read corresponding comments and be careful\n", file);
		fputs("// Import comments (0 - No; 1 - Yes)\n", file);
		strcpy(buffer, "comments=");
		itoa(conf->comments, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// Import labels (0 - No; 1 - Yes)\n", file);
		strcpy(buffer, "labels=");
		itoa(conf->labels, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// Check for collisions (0 - Overwrite silently; 1 - Skip if collision)\n", file);
		strcpy(buffer, "collisionchecks=");
		itoa(conf->collisionchecks, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("//Apply names to (0 - Currently viewed module; 1 - Debuggee)\n", file);
		strcpy(buffer, "applytodebuggee=");
		itoa(conf->applytodebuggee, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// Autoimport map if present (0 - Disabled; 1 - Ask to import; 2 - Import always)\n", file);
		strcpy(buffer, "autoimport=");
		itoa(conf->aimport, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// Demangle names (0 - No; 1 - Yes)\n", file);
		strcpy(buffer, "demangle=");
		itoa(conf->demangle, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// Filter names using masks (0 - No; 1 - Yes)\n", file);
		strcpy(buffer, "usemasks=");
		itoa(conf->usemasks, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		fputs("// User specified masks (customfilter=n). The value n specifies\n", file);
		fputs("// the number of masks, next n lines are masks themselves.\n", file);
		fputs("// If the line is invalid it will be ignored\n", file);
		strcpy(buffer, "customfilter=");
		itoa(conf->customfilter->count, value, 10);
		strcat(buffer, value);
		strcat(buffer, "\n");
		fputs(buffer, file);
		msk = (MASK*)conf->customfilter->first;
		while (msk)
		{
			strcpy(buffer, msk->buffer);
			strcat(buffer, "\n");
			fputs(buffer, file);
			msk = msk->next;
		}
		fclose(file);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

PCHAR configfile_locate(PCHAR buffer)
{
	if (buffer)
	{
		GetModuleFileName(g_hInstDLL, buffer, MAX_PATH);
		strcpy(strrchr(buffer, '\\'), "\\mapimp.cfg");
	}
	return buffer;
}

void configfile_defaults(CONFIG* conf)
{
	conf->collisionchecks = TRUE;
	conf->comments = TRUE;
	conf->customfilter = list_create();
	conf->labels = TRUE;
	conf->applytodebuggee = TRUE;
	conf->demangle = FALSE;
	conf->usemasks = FALSE;
	conf->aimport = AUTOIMPORT_ASK;
}

CONFIG* configfile_parse(PCHAR path)
{
	FILE* file = fopen(path, "r");
	char buffer[TEXTLEN], param[20];
	ULONG len, counter;
	CONFIG* conf = malloc(sizeof(CONFIG));
	configfile_defaults(conf);
	if (file)
	{
		while(fgets(buffer, TEXTLEN, file))
		{
			len = strlen("comments");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("comments", param))
			{
				strtok(buffer, " =-\n");
				conf->comments = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("labels");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("labels", param))
			{
				strtok(buffer, " =-\n");
				conf->labels = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("collisionchecks");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("collisionchecks", param))
			{
				strtok(buffer, " =-\n");
				conf->collisionchecks = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("applytodebuggee");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("applytodebuggee", param))
			{
				strtok(buffer, " =-\n");
				conf->applytodebuggee = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("autoimport");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("autoimport", param))
			{
				strtok(buffer, " =-\n");
				conf->aimport = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("demangle");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("demangle", param))
			{
				strtok(buffer, " =-\n");
				conf->demangle = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("usemasks");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("usemasks", param))
			{
				strtok(buffer, " =-\n");
				conf->usemasks = atoi(strtok(NULL, " =-\n"));
			}
			len = strlen("customfilter");
			strncpy(param, buffer, len);
			param[len] = '\0';
			if(!stricmp("customfilter", param))
			{
				strtok(buffer, " =-\n");
				conf->customfilter = list_create();
				counter = atoi(strtok(NULL, " =-\n"));
				for (conf->customfilter->count = 0; conf->customfilter->count < counter;)
				{
					if (fgets(buffer, TEXTLEN, file))
					{
						list_addmask(conf->customfilter, strtok(buffer, "\n"));
					}
					else
					{
						/* Warning! Breaks the inner loop ( while(fgets(buffer, TEXTLEN, file)) ) */
						goto _break;
					}
				}
			}
		}
		_break:
		fclose(file);
	}
	return conf;
}


void edit_mask_(HWND wnd, HWND hwnd)
{
	char debug[TEXTLEN];
	RECT rect;
	char buffer[TEXTLEN], errbuf[TEXTLEN + ERRORBUFLEN];
	MASK* mask;
	int counter, index, height;
	MASK tmpmask;
	int result;

	index = SendMessage(wnd, LB_GETCURSEL, 0, 0);
	if (index >= 0)
	{
		EnableWindow(hwnd, FALSE);
		SendMessage(wnd, LB_GETTEXT, index, (LPARAM)buffer);
		result = TRUE;
		while (result)
		{
			result = Gettextxy("Edit mask:", buffer, 0, INPUTWND_TYPE, Plugingetvalue(VAL_WINDOWFONT),
			GetSystemMetrics(SM_CXSCREEN) / 2, GetSystemMetrics(SM_CYSCREEN) / 2);
			if ((result > 0) && (result < TEXTLEN))
			{
				result = mask_compile(&tmpmask, buffer);
				if (result)
				{
					strcpy(errbuf, buffer);
					strcat(errbuf, "\n");
					mask_error(result, &tmpmask.regex, strrchr(errbuf, '\n') + 1);
					MessageBox(g_hwndOlly, errbuf, "Mask syntax error", MB_ICONERROR);
				}
				else
				{
					SendMessage(wnd, LB_DELETESTRING, index, (LPARAM)buffer);
					SendMessage(wnd, LB_SETCURSEL, SendMessage(wnd, LB_ADDSTRING, 0, (LPARAM)buffer), 0);
				}
			}
			else
			{
				break;
			}
		}
		EnableWindow(hwnd, TRUE);
		SetFocus(wnd);
	}
}

LRESULT CALLBACK configwnd_msgproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	char debug[TEXTLEN];
	HWND wnd;
	RECT rect;
	char buffer[TEXTLEN], errbuf[TEXTLEN + ERRORBUFLEN];
	MASK* mask;
	int counter, index, height;
	MASK tmpmask;
	int result;
	switch (msg)
	{
		case WM_COMMAND:
			if (HIWORD(wparam) == LBN_DBLCLK)
			{
				if (LOWORD(wparam) == ID_MASKS)
				{
					edit_mask_(lparam, hwnd);
				}
			}
			else
			switch (LOWORD(wparam))
			{
				case ID_COMMENTS:
					if (HIWORD(wparam) == 1)
					{
						CheckDlgButton(hwnd, ID_COMMENTS, IsDlgButtonChecked(hwnd, ID_COMMENTS) ^ BST_CHECKED);
					}
					break;

				case ID_LABELS:
					if (HIWORD(wparam) == 1)
					{
						CheckDlgButton(hwnd, ID_LABELS, IsDlgButtonChecked(hwnd, ID_LABELS) ^ BST_CHECKED);
					}
					break;

				case ID_USEMASKS:
					if (HIWORD(wparam) == 1)
					{
						CheckDlgButton(hwnd, ID_USEMASKS, IsDlgButtonChecked(hwnd, ID_USEMASKS) ^ BST_CHECKED);
					}
					break;

				case ID_DEMANGLE:
					if (HIWORD(wparam) == 1)
					{
						CheckDlgButton(hwnd, ID_DEMANGLE, IsDlgButtonChecked(hwnd, ID_DEMANGLE) ^ BST_CHECKED);
					}
					break;

				case ID_SKIP:
					CheckDlgButton(hwnd, ID_SKIP, BST_CHECKED);
					CheckDlgButton(hwnd, ID_OVERWRITE, BST_UNCHECKED);
					break;

				case ID_OVERWRITE:
					CheckDlgButton(hwnd, ID_SKIP, BST_UNCHECKED);
					CheckDlgButton(hwnd, ID_OVERWRITE, BST_CHECKED);
					break;

				case ID_MODULE:
					CheckDlgButton(hwnd, ID_MODULE, BST_CHECKED);
					CheckDlgButton(hwnd, ID_DEBUGGEE, BST_UNCHECKED);
					break;

				case ID_DEBUGGEE:
					CheckDlgButton(hwnd, ID_DEBUGGEE, BST_CHECKED);
					CheckDlgButton(hwnd, ID_MODULE, BST_UNCHECKED);
					break;

				case ID_ASKTOIMPORT:
					CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_CHECKED);
					CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_UNCHECKED);
					CheckDlgButton(hwnd, ID_DONOTHING, BST_UNCHECKED);
					break;

				case ID_IMPORTALWAYS:
					CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_UNCHECKED);
					CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_CHECKED);
					CheckDlgButton(hwnd, ID_DONOTHING, BST_UNCHECKED);
					break;

				case ID_DONOTHING:
					CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_UNCHECKED);
					CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_UNCHECKED);
					CheckDlgButton(hwnd, ID_DONOTHING, BST_CHECKED);
					break;

				case ID_CANCEL:
					SendMessage(hwnd, WM_CLOSE, 0, 0);
					break;

				case ID_APPLY:
					if (IsDlgButtonChecked(hwnd, ID_COMMENTS) == BST_CHECKED)
					{
						g_Config->comments = TRUE;
					}
					else
					{
						g_Config->comments = FALSE;
					}
					if (IsDlgButtonChecked(hwnd, ID_LABELS) == BST_CHECKED)
					{
						g_Config->labels = TRUE;
					}
					else
					{
						g_Config->labels = FALSE;
					}
					if (IsDlgButtonChecked(hwnd, ID_SKIP) == BST_CHECKED)
					{
						g_Config->collisionchecks = TRUE;
					}
					else
					{
						g_Config->collisionchecks = FALSE;
					}
					if (IsDlgButtonChecked(hwnd, ID_DEBUGGEE) == BST_CHECKED)
					{
						g_Config->applytodebuggee = TRUE;
					}
					else
					{
						g_Config->applytodebuggee = FALSE;
					}
					if (IsDlgButtonChecked(hwnd, ID_ASKTOIMPORT) == BST_CHECKED)
					{
						g_Config->aimport = AUTOIMPORT_ASK;
					}
					if (IsDlgButtonChecked(hwnd, ID_IMPORTALWAYS) == BST_CHECKED)
					{
						g_Config->aimport = AUTOIMPORT_ALWAYS;
					}
					if (IsDlgButtonChecked(hwnd, ID_DONOTHING) == BST_CHECKED)
					{
						g_Config->aimport = AUTOIMPORT_DISABLED;
					}
					if (IsDlgButtonChecked(hwnd, ID_USEMASKS) == BST_CHECKED)
					{
						g_Config->usemasks = TRUE;
					}
					else
					{
						g_Config->usemasks = FALSE;
					}
					if (IsDlgButtonChecked(hwnd, ID_DEMANGLE) == BST_CHECKED)
					{
						g_Config->demangle = TRUE;
					}
					else
					{
						g_Config->demangle = FALSE;
					}
					wnd = FindWindowEx(hwnd, 0, "listbox", 0);
					list_freemasks(g_Config->customfilter);
					g_Config->customfilter = list_create();
					for (counter = 0; counter < SendMessage(wnd, LB_GETCOUNT, 0, 0); counter++)
					{
						SendMessage(wnd, LB_GETTEXT, counter, (LPARAM)buffer);
						list_addmask(g_Config->customfilter, buffer);
					}
					configfile_create(configfile_locate(buffer), g_Config);
					SendMessage(hwnd, WM_CLOSE, 0, 0);
					break;

				case ID_DELETE:
					wnd = FindWindowEx(hwnd, 0, "listbox", 0);
					index = SendMessage(wnd, LB_GETCURSEL, 0, 0);
					SendMessage(wnd, LB_DELETESTRING, index, 0);
					if (SendMessage(wnd, LB_SETCURSEL, index, 0) == LB_ERR)
					{
						SendMessage(wnd, LB_SETCURSEL, index - 1, 0);
					}
					break;

				case ID_ADD:
					wnd = FindWindowEx(hwnd, 0, "listbox", 0);
					EnableWindow(hwnd, FALSE);
					buffer[0] = '\0';
					result = TRUE;
					while (result)
					{
						result = Gettextxy("Input mask:", buffer, 0, INPUTWND_TYPE, Plugingetvalue(VAL_WINDOWFONT),
							GetSystemMetrics(SM_CXSCREEN) / 2, GetSystemMetrics(SM_CYSCREEN) / 2);
						if ((result > 0) && (result < TEXTLEN))
						{
							result = mask_compile(&tmpmask, buffer);
							if (result)
							{
								strcpy(errbuf, buffer);
								strcat(errbuf, "\n");
								mask_error(result, &tmpmask.regex, strrchr(errbuf, '\n') + 1);
								MessageBox(g_hwndOlly, errbuf, "Mask syntax error", MB_ICONERROR);
							}
							else
							{
								SendMessage(wnd, LB_SETCURSEL, SendMessage(wnd, LB_ADDSTRING, 0, (LPARAM)buffer), 0);
							}
						}
						else
						{
							break;
						}
					}
					EnableWindow(hwnd, TRUE);
					SetFocus(wnd);
					break;

				case ID_EDIT:
					wnd = FindWindowEx(hwnd, 0, "listbox", 0);
					edit_mask_(wnd, hwnd);
					break;
			}
			break;

		case WM_CREATE:
			EnableWindow(g_hwndOlly, FALSE);
			GetClientRect(hwnd, &rect);
			height = rect.bottom;
			GetWindowRect(hwnd, &rect);
			height = rect.bottom - rect.top - height + OPTWND_WINDOW_HEIGHT;
			SetWindowPos(hwnd, NULL, 0, 0, rect.right - rect.left, height, SWP_NOMOVE | SWP_NOZORDER);

			wnd = CreateWindowEx(0, "Button", "Import objects:", 0x50020007, 4, 0, 128, 64, hwnd, (HMENU) ID_IMPORT, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Comments", 0x50010003, 12, 16, 112, 20, hwnd, (HMENU) ID_COMMENTS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Labels", 0x50010003, 12, 36, 112, 20, hwnd, (HMENU) ID_LABELS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			wnd = CreateWindowEx(0, "Button", "Collisions:", 0x50020007, 4, 68, 128, 64, hwnd, (HMENU) ID_COLLISIONS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Skip if collision", 0x50010009, 12, 86, 116, 16, hwnd, (HMENU) ID_SKIP, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Overwrite", 0x50000009, 12, 106, 116, 16, hwnd, (HMENU) ID_OVERWRITE, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			wnd = CreateWindowEx(0, "Button", "Apply names to:", 0x50020007, 4, 136, 128, 64, hwnd, (HMENU) ID_APPLYTO, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Viewed module", 0x50010009, 12, 154, 116, 16, hwnd, (HMENU) ID_MODULE, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Debuggee", 0x50010009, 12, 174, 116, 16, hwnd, (HMENU) ID_DEBUGGEE, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			wnd = CreateWindowEx(0, "Button", "If map file found:", 0x50020007, 4, 204, 128, 80, hwnd, (HMENU) ID_AUTOIMPORT, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Ask to import", 0x50000009, 12, 222, 116, 16, hwnd, (HMENU) ID_ASKTOIMPORT, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "&Import always", 0x50000009, 12, 242, 116, 16, hwnd, (HMENU) ID_IMPORTALWAYS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "Do &nothing", 0x50000009, 12, 262, 116, 16, hwnd, (HMENU) ID_DONOTHING, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			wnd = CreateWindowEx(0, "Button", "Filter:", 0x50020007, 136, 0, 208, 284, hwnd, (HMENU) ID_FILTER, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0x200, "listbox", "", WS_CHILD | WS_VISIBLE | LBS_STANDARD | WS_VSCROLL, 144, 16, 192, 208, hwnd, (HMENU) ID_MASKS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			SetFocus(wnd);
			wnd = CreateWindowEx(0, "Button", "Add", 0x50012F00, 144, 222, 61, 16, hwnd, (HMENU) ID_ADD, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "Edit", 0x50012F00, 209, 222, 61, 16, hwnd, (HMENU) ID_EDIT, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "Delete", 0x50012F00, 274, 222, 61, 16, hwnd, (HMENU) ID_DELETE, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "Use &masks", 0x50010003, 144, 242, 116, 16, hwnd, (HMENU) ID_USEMASKS, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "D&emangle names", 0x50010003, 144, 262, 116, 16, hwnd, (HMENU) ID_DEMANGLE, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			wnd = CreateWindowEx(0, "Button", "Apply", 0x50012F00, 204, 288, 68, 20, hwnd, (HMENU) ID_APPLY, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);
			wnd = CreateWindowEx(0, "Button", "Cancel", 0x50012F00, 276, 288, 68, 20, hwnd, (HMENU) ID_CANCEL, g_hInstance, NULL);
			SendMessage(wnd, WM_SETFONT, (WPARAM) g_hFont, TRUE);

			if (g_Config->comments)
			{
				CheckDlgButton(hwnd, ID_COMMENTS, BST_CHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_COMMENTS, BST_UNCHECKED);
			}
			if (g_Config->labels)
			{
				CheckDlgButton(hwnd, ID_LABELS, BST_CHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_LABELS, BST_UNCHECKED);
			}
			if (g_Config->collisionchecks)
			{
				CheckDlgButton(hwnd, ID_SKIP, BST_CHECKED);
				CheckDlgButton(hwnd, ID_OVERWRITE, BST_UNCHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_SKIP, BST_UNCHECKED);
				CheckDlgButton(hwnd, ID_OVERWRITE, BST_CHECKED);
			}
			if (g_Config->applytodebuggee)
			{
				CheckDlgButton(hwnd, ID_DEBUGGEE, BST_CHECKED);
				CheckDlgButton(hwnd, ID_MODULE, BST_UNCHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_DEBUGGEE, BST_UNCHECKED);
				CheckDlgButton(hwnd, ID_MODULE, BST_CHECKED);
			}
			if (g_Config->aimport == AUTOIMPORT_ASK)
			{
				CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_CHECKED);
				CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_UNCHECKED);
				CheckDlgButton(hwnd, ID_DONOTHING, BST_UNCHECKED);
			}
			else if (g_Config->aimport == AUTOIMPORT_ALWAYS)
			{
				CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_CHECKED);
				CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_UNCHECKED);
				CheckDlgButton(hwnd, ID_DONOTHING, BST_UNCHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_DONOTHING, BST_CHECKED);
				CheckDlgButton(hwnd, ID_ASKTOIMPORT, BST_UNCHECKED);
				CheckDlgButton(hwnd, ID_IMPORTALWAYS, BST_UNCHECKED);
			}
			if (g_Config->usemasks)
			{
				CheckDlgButton(hwnd, ID_USEMASKS, BST_CHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_USEMASKS, BST_UNCHECKED);
			}
			if (g_Config->demangle)
			{
				CheckDlgButton(hwnd, ID_DEMANGLE, BST_CHECKED);
			}
			else
			{
				CheckDlgButton(hwnd, ID_DEMANGLE, BST_UNCHECKED);
			}
			mask = (MASK*)g_Config->customfilter->first;
			wnd = FindWindowEx(hwnd, 0, "listbox", 0);
			while (mask)
			{
				SendMessage(wnd, LB_ADDSTRING, 0, (LPARAM)mask->buffer);
				mask = mask->next;
			}
			break;

		case WM_CLOSE:
			EnableWindow(g_hwndOlly, TRUE);
			SetFocus(g_hwndOlly);
			DestroyWindow(hwnd);
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		default:
			return DefWindowProc(hwnd, msg, wparam, lparam);
	}
	return FALSE;
}

void configwnd_create()
{
	WNDCLASS wc;
	HWND wnd;
	MSG msg;
	ACCEL accel[16];
	HACCEL acctable;
	accel[0].cmd = ID_COMMENTS;
	accel[0].fVirt = FALT | FVIRTKEY;
	accel[0].key = 'C';
	accel[1].cmd = ID_LABELS;
	accel[1].fVirt = FALT | FVIRTKEY;
	accel[1].key = 'L';
	accel[2].cmd = ID_SKIP;
	accel[2].fVirt = FALT | FVIRTKEY;
	accel[2].key = 'S';
	accel[3].cmd = ID_OVERWRITE;
	accel[3].fVirt = FALT | FVIRTKEY;
	accel[3].key = 'O';
	accel[4].cmd = ID_MODULE;
	accel[4].fVirt = FALT | FVIRTKEY;
	accel[4].key = 'V';
	accel[5].cmd = ID_DEBUGGEE;
	accel[5].fVirt = FALT | FVIRTKEY;
	accel[5].key = 'D';
	accel[6].cmd = ID_ASKTOIMPORT;
	accel[6].fVirt = FALT | FVIRTKEY;
	accel[6].key = 'A';
	accel[7].cmd = ID_IMPORTALWAYS;
	accel[7].fVirt = FALT | FVIRTKEY;
	accel[7].key = 'I';
	accel[8].cmd = ID_DONOTHING;
	accel[8].fVirt = FALT | FVIRTKEY;
	accel[8].key = 'N';
	accel[9].cmd = ID_ADD;
	accel[9].fVirt = FCONTROL | FVIRTKEY;
	accel[9].key = 'A';
	accel[10].cmd = ID_EDIT;
	accel[10].fVirt = FCONTROL | FVIRTKEY;
	accel[10].key = 'E';
	accel[11].cmd = ID_DELETE;
	accel[11].fVirt = FVIRTKEY;
	accel[11].key = VK_DELETE;
	accel[12].cmd = ID_USEMASKS;
	accel[12].fVirt = FALT | FVIRTKEY;
	accel[12].key = 'M';
	accel[13].cmd = ID_DEMANGLE;
	accel[13].fVirt = FALT | FVIRTKEY;
	accel[13].key = 'E';
	accel[14].cmd = ID_APPLY;
	accel[14].fVirt = FVIRTKEY;
	accel[14].key = VK_RETURN;
	accel[15].cmd = ID_CANCEL;
	accel[15].fVirt = FVIRTKEY;
	accel[15].key = VK_ESCAPE;
	acctable = CreateAcceleratorTable(accel, 16);
	InitCommonControls();
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(g_hInstance, OPTWND_ICON_NAME);
	wc.hInstance = g_hInstance;
	wc.lpszMenuName = NULL;
	wc.style = CS_PARENTDC | CS_DBLCLKS;
	wc.lpfnWndProc = configwnd_msgproc;
	wc.lpszClassName = OPTWND_CLASS_NAME;
	RegisterClass(&wc);
	g_hFont = CreateFont(-10, 0, 0, 0, FW_NORMAL, 0,
				0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
				DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, OPTWND_FONT_NAME);
	wnd = CreateWindowEx(0, OPTWND_CLASS_NAME, OPTWND_WINDOW_NAME, WS_VISIBLE | WS_SYSMENU | WS_OVERLAPPED | DS_SYSMODAL,
			(GetSystemMetrics(SM_CXSCREEN) - OPTWND_WINDOW_WIDTH) / 2,
			(GetSystemMetrics(SM_CYSCREEN) - OPTWND_WINDOW_HEIGHT) / 2,
			OPTWND_WINDOW_WIDTH, OPTWND_WINDOW_HEIGHT, g_hwndOlly, NULL, g_hInstance, NULL);
	ShowWindow(wnd, SW_SHOWNORMAL);
	UpdateWindow(wnd);
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(wnd, acctable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	DeleteObject(g_hFont);
	UnregisterClass(OPTWND_CLASS_NAME, g_hInstance);
	DestroyAcceleratorTable(acctable);
}

void mapfile_apply(LIST* names)
{
	PCHAR undecorated, pname;
	char buffer[TEXTLEN];
	HANDLE hFile, hMapping, hProcess;
	LPVOID pMapping;
	PIMAGE_DOS_HEADER dos;
	PIMAGE_NT_HEADERS nt;
	PIMAGE_SECTION_HEADER sh;
	ULONG base, counter, total, filtered, applied, needed, addr, result, cbase, csize, nsegments;
	HMODULE* modules;
	t_module* module;
	PULONG segments;
	NAME* nm;
	LIST* rmtable;
	if (g_Config->applytodebuggee)
	{
		pname = (PCHAR)Plugingetvalue(VAL_EXEFILENAME);
		hProcess = (HANDLE)Plugingetvalue(VAL_HPROCESS);
		EnumProcessModules(hProcess, NULL, 0, &needed);
		modules = malloc(needed * sizeof(HMODULE));
		EnumProcessModules(hProcess, modules, needed, &needed);
		for (counter = 0; counter < needed / sizeof(HMODULE); counter++)
		{
			GetModuleFileNameEx(hProcess, modules[counter], buffer, TEXTLEN);
			if (!strcmp(pname, buffer))
			{
				base = (ULONG)modules[counter];
				break;
			}
		}
		free(modules);
	}
	else
	{
		Getdisassemblerrange(&cbase, &csize);
		module = Findmodule(cbase);
		if (module)
		{
			base = (ULONG)module->base;
			pname = &module->path;
		}
		else
		{
			return;
		}
	}
	hFile = CreateFile(pname, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, 0);
		if (hMapping)
		{
			pMapping = MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, 0);
			dos = (PIMAGE_DOS_HEADER)pMapping;
			nt = (PIMAGE_NT_HEADERS)((ULONG)dos + dos->e_lfanew);
			nsegments = nt->FileHeader.NumberOfSections + 1;
			segments = malloc(nsegments * sizeof(ULONG));
			sh = IMAGE_FIRST_SECTION(nt);
			segments[0] = 0;
			for(counter = 1; counter < nsegments; counter++)
			{
				if (!sh->PointerToRelocations &&
					!sh->PointerToLinenumbers &&
					!sh->NumberOfRelocations &&
					!sh->NumberOfLinenumbers &&
					sh->Characteristics)
				{
					segments[counter] = sh->VirtualAddress;
				}
				else
				{
					break;
				}
				sh++;
			}
			nsegments = counter;
			UnmapViewOfFile(pMapping);
			CloseHandle(hMapping);
			CloseHandle(hFile);
			nm = (NAME*)names->first;
			rmtable = list_create();
			total = 0;
			filtered = 0;
			applied = 0;
			while (nm)
			{
				if (nm->segment < nsegments)
				{
					if (g_Config->demangle)
					{
						undecorated = malloc(2 * nm->size * sizeof(char));
						result = Demanglename(nm->buffer, NM_LIBRARY, undecorated);
						if (result)
						{
							free(nm->buffer);
							nm->size = result + 1;
							nm->buffer = undecorated;
						}
						else
						{
							free(undecorated);
						}
					}
					if (g_Config->usemasks)
					{
						result = mask_filter(nm);
						if (result)
						{
							filtered++;
							if (result & FILTER_SKIP)
							{
								list_addname(rmtable, nm->buffer, 0, nm->segment, nm->offset);
							}
						}
					}
					addr = base + segments[nm->segment] + nm->offset;
					if (g_Config->comments)
					{
						if (g_Config->collisionchecks)
						{
							if (!Findname(addr, NM_COMMENT, NULL))
							{
								if (!Quickinsertname(addr, NM_COMMENT, nm->buffer))
								{
									applied++;
								}
							}
						}
						else
						{
							if (!Quickinsertname(addr, NM_COMMENT, nm->buffer))
							{
								applied++;
							}
						}
					}
					if (g_Config->labels)
					{
						if (g_Config->collisionchecks)
						{
							if (!Findlabel(addr, NULL))
							{
								if (!Quickinsertname(addr, NM_LABEL, nm->buffer))
								{
									applied++;
								}
							}
						}
						else
						{
							if (!Quickinsertname(addr, NM_LABEL, nm->buffer))
							{
								applied++;
							}
						}
					}
				}
				total++;
				Progress(total * 1000 / names->count, "Inserting names");
				nm = nm->next;
			}
			Progress(0, "");
			Infoline("Merging names");
			Mergequicknames();
			if (!g_Config->collisionchecks)
			{
				Infoline("Cleaning skipped entries");
				nm = (NAME*)rmtable->first;
				while (nm)
				{
					addr = base + segments[nm->segment] + nm->offset;
					if (g_Config->comments)
					{
						Insertname(addr, NM_COMMENT, nm->buffer);
					}
					if (g_Config->labels)
					{
						Insertname(addr, NM_LABEL, nm->buffer);
					}
					nm = nm->next;
				}
			}
			isAlready = 1;
			list_freenames(rmtable);
			Infoline("Total loaded: %d, Names applied: %d, Names filtered: %d", names->count, applied, filtered);
		}
		else
		{
			Flash("Failed to create file mapping");
			Addtolist(0, 1, "MAPIMP: failed to create file mapping");
			CloseHandle(hFile);
		}
	}
	else
	{
		Flash("Failed to obtain file handle");
		Addtolist(0, 1, "MAPIMP: failed to obtain file handle");
	}
}

LIST* mapfile_parse(PCHAR path)
{
	FILE* file = fopen(path, "r");
	LIST* list = FALSE;
	BYTE segment;
	ULONG offset, len, counter, ntokens = 0;
	PCHAR buffer, oldbuffer;
	if (file)
	{
		buffer = malloc(MAPBUFLEN * sizeof(char));
		oldbuffer = buffer;
		for (counter = 0; counter < 2; counter++)
		{
			while (fgets(buffer, MAPBUFLEN, file))
			{
				buffer[strlen(buffer) - 1] = '\0';
				if (strstr(buffer, "Address         "))
				{
					list = list_create();
					ntokens = 1;
					strtok(buffer, " ");
					while (strtok(NULL, " "))
					{
						ntokens++;
					}
					fgets(buffer, MAPBUFLEN, file);
					break;
				}
				else if (strstr(buffer, "Static symbols"))
				{
					fgets(buffer, MAPBUFLEN, file);
					break;
				}
				else
				{
					continue;
				}
			}
			if (ntokens)
			{
				while (fgets(buffer, MAPBUFLEN, file))
				{
					if (buffer[0] == ' ')
					{
						buffer++;
						buffer[4] = '\0';
						segment = strtol(buffer, NULL, 16);
						buffer += 5;
						buffer[8] = '\0';
						offset = strtol(buffer, NULL, 16);
						buffer += 15;
						/*
							Id like to make a lil bit of sence here. ntokens
							contains a number of words in the column names string
							of a name table. If there are 4 words: "Address",
							"Publics", "by" and "Value" or "Name" there are only 2 columns
							in the table. If there are more so every name should
							be delimited from another column in the record by space
							character and we have to handle that
						*/
						if (ntokens > 4)
						{
							for (len = 0; buffer[len] != '\0'; len++)
							{
								if (buffer[len] == ' ')
								{
									buffer[len] = '\0';
									break;
								}
							}
						}
						else
						{
							len = strlen(buffer) - 1;
							buffer[len] = '\0';
						}
						list_addname(list, buffer, len, segment, offset);
						buffer = oldbuffer;
					}
					else
					{
						break;
					}
				}
			}
		}
		free(buffer);
		fclose(file);
	}
	return list;
}

BOOL WINAPI DllMain(HINSTANCE hi, DWORD reason, LPVOID reserved)
{
	if (reason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hi);
		g_hInstDLL = hi;
	}
	return TRUE;
}

int _export cdecl ODBG_Plugininit(int ollydbgversion, HWND hw, ULONG *features)
{
	char path[MAX_PATH];
	if (ollydbgversion < PLUGIN_VERSION)
	{
		MessageBox(hw, "Current OllyDbg version is not supported", "Unable to load plugin", MB_ICONERROR);
		return -1;
	}
	g_Config = configfile_parse(configfile_locate(path));
	g_hInstance = GetModuleHandle(NULL);
	g_hwndOlly = hw;
	g_LastSession = malloc(MAX_PATH * sizeof(char));
	g_SessionStarted = FALSE;
	Addtolist(0, 0, "MAPIMP Plugin v0.6");
	Addtolist(0, -1, "  Coded by takerZ, 2009");
	Addtolist(0, 1, "  mod by BoRoV, 2009");
	return 0;
}

int _export cdecl ODBG_Plugindata(char shortname[32])
{
	strcpy(shortname, "mapimp");
	return PLUGIN_VERSION;
}

int _export cdecl ODBG_Pluginmenu(int origin, char data[4096], void *item)
{
	if (origin == PM_MAIN)
	{
		strcpy(data, "0 Import map, 1 Options |3 &About");
		return 1;
	}
	return 0;
}

void _export cdecl ODBG_Pluginreset()
{
	strcpy(g_LastSession, (PCHAR)Plugingetvalue(VAL_EXEFILENAME));
	g_SessionStarted = FALSE;
}

int _export cdecl ODBG_Pausedex(int reason, int extdata, t_reg *reg, DEBUG_EVENT *debugevent)
{
	LIST* names;
	WIN32_FIND_DATA fdata;
	char path[MAX_PATH];
	char *pos;
	HANDLE result;

	if ((reason & PP_INT3BREAK) && strcmp(g_LastSession, (PCHAR)Plugingetvalue(VAL_EXEFILENAME)) && !g_SessionStarted)
	{
		g_SessionStarted = TRUE;
		strcpy(path, (PCHAR)Plugingetvalue(VAL_EXEFILENAME));
		pos = strrchr(path, '.');
		if (pos == NULL)
			strcat(path, ".MAP");
		else
			strcpy(pos, ".MAP");
		result = FindFirstFile(path, &fdata);
		if (result != INVALID_HANDLE_VALUE)
		{
			FindClose(result);
			if ((isAlready == 0) && (g_Config->aimport == AUTOIMPORT_ASK) && (MessageBox(g_hwndOlly, "Corresponding map file found. Do you want to import it now?",
				"MAPIMP", MB_YESNO | MB_ICONQUESTION) == IDYES) || (g_Config->aimport == AUTOIMPORT_ALWAYS))
			{
				names = mapfile_parse(path);
				if (names)
				{
					mapfile_apply(names);
					list_freenames(names);
					Setcpu(0, 0, 0, 0, CPU_ASMFOCUS);
				}
				else
				{
					Flash("Failed to open the file");
				}
			}
		}
	}
	return 0;
}

void _export cdecl ODBG_Pluginaction(int origin, int action, void *item)
{
	LIST* names;
	char path[TEXTLEN];
	t_status status;
	if (origin == PM_MAIN)
	{
		switch (action)
		{
			case ACTION_IMPORT:
				status = Getstatus();
				if (status != STAT_NONE && status != STAT_FINISHED && status != STAT_CLOSING)
				{
					strcpy(path, ".\\");
					if (Browsefilename("Select map file to import", path, ".MAP", 0))
					{
						names = mapfile_parse(path);
						if (names)
						{
							mapfile_apply(names);
							list_freenames(names);
							Setcpu(0, 0, 0, 0, CPU_ASMFOCUS);
						}
						else
						{
							Flash("Failed to open the file");
						}
					}
				}
				break;
			case ACTION_OPTIONS:
				configwnd_create();
				break;
			case ACTION_ABOUT:
				MessageBox(g_hwndOlly, "MAPIMP plugin v0.6\n\nCoded by takerZ/tPORt\nmod by BoRoV/TSRh\n\n2009", "About MAPIMP", MB_ICONINFORMATION);
				break;
			default:
				break;
		}
	}
}

int _export cdecl ODBG_Pluginshortcut(int origin, int ctrl, int alt, int shift, int key, void* item)
{
	if (origin == PM_MAIN)
	{
		if (ctrl && shift && key == 'I')
		{
			ODBG_Pluginaction(origin, ACTION_IMPORT, NULL);
		}
		else if (ctrl && shift && key == 'M')
		{
			ODBG_Pluginaction(origin, ACTION_OPTIONS, NULL);
		}
	}
	return origin;
}

void _export cdecl ODBG_Plugindestroy()
{
	list_freemasks(g_Config->customfilter);
	free(g_LastSession);
	free(g_Config);
}
void _export cdecl ODBG_Pluginsaveudd(t_module *pmod, int ismainmodule)
{
	if (ismainmodule != 0)
		Pluginsaverecord(TAG_MAPIMP, 4, &isAlready);
}

int _export cdecl ODBG_Pluginuddrecord(t_module *pmod, int ismainmodule, ulong tag, ulong size, void *data)
{
	if ((ismainmodule != 0) && (tag == TAG_MAPIMP))
	{
		isAlready = *(DWORD *)data;
		return 1;
	};

	return 0;
}