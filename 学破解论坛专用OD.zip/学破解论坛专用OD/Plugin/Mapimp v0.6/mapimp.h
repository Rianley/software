#ifndef __MAPIMP_H__
#define __MAPIMP_H__

typedef struct _MASK
{
	PVOID next;
	PCHAR buffer;
	PCHAR repl;
	int type;
	regex_t regex;
} MASK;

typedef struct _NAME
{
	PVOID next;
	ULONG size;
	PCHAR buffer;
	ULONG offset;
	BYTE segment;
} NAME;

typedef struct _LIST
{
	ULONG count;
	LPVOID* first;
	LPVOID* last;
} LIST;

typedef struct _CONFIG
{
	BOOL comments;
	BOOL labels;
	BOOL collisionchecks;	
	int aimport;
	BOOL applytodebuggee;
	BOOL demangle;
	BOOL usemasks;
	LIST* customfilter;
} CONFIG;

/* mask_compile output defenitions */
typedef enum
{
	FILTER_NOERROR = 0,
	FILTER_INVALID_MASK = REG_NOMATCH + 1,
	FILTER_INVALID_KEY,
	FILTER_INVALID_REPLACEMENT
} __filter_error;

/*	Value for .udd	*/
#define TAG_MAPIMP			 0x504D694D

#define ERRORBUFLEN          60
#define MAPBUFLEN            1024

/* Plugin action identifiers */
#define ACTION_IMPORT        0
#define ACTION_OPTIONS       1
#define ACTION_ABOUT         3

/* mask_filter output defenitions */
#define FILTER_NOTHING       0
#define FILTER_SKIP          1
#define FILTER_CUT           2
#define FILTER_REPLACE       4

/* autoimport option defenitions */
#define AUTOIMPORT_DISABLED  0
#define AUTOIMPORT_ASK       1
#define AUTOIMPORT_ALWAYS    2

/* Option window defenitions */
#define OPTWND_CLASS_NAME    "mapimp_wnd"
#define OPTWND_WINDOW_NAME   "Options"
#define OPTWND_FONT_NAME     "Verdana"
#define OPTWND_ICON_NAME     "ICO_OPTIONS"
#define OPTWND_WINDOW_WIDTH  354
#define OPTWND_WINDOW_HEIGHT 312

#define INPUTWND_TYPE        196

#define ID_CANCEL            2000
#define ID_APPLY             2001
#define ID_ADD               2002
#define ID_DELETE            2003
#define ID_USEMASKS          2004
#define ID_COLLISIONS        2005
#define ID_IMPORT            2006
#define ID_MASKS             2007
#define ID_FILTER            2008
#define ID_OVERWRITE         2009
#define ID_SKIP              2010
#define ID_LABELS            2011
#define ID_COMMENTS          2012
#define ID_EDIT              2013
#define ID_AUTOIMPORT        2014
#define ID_ASKTOIMPORT       2015
#define ID_IMPORTALWAYS      2016
#define ID_DONOTHING         2017
#define ID_APPLYTO           2018
#define ID_MODULE            2019
#define ID_DEBUGGEE          2020
#define ID_DEMANGLE          2021

#endif